import React from "react";
import { ScrollView, StyleSheet, View, AsyncStorage } from "react-native";
import { Button, Layout, LayoutElement, Text } from "@ui-kitten/components";
import { EdgeInsets, useSafeArea } from "react-native-safe-area-context";
import { TodoDetailsScreenProps } from "../../navigation/todo.navigator";
import { Toolbar } from "../../components/toolbar.component";
import { ImageOverlay } from "../../components/image-overlay.component";
import { ProgressBar } from "../../components/progress-bar.component";
import { Todo } from "../../data/todo.model";
import CachedImage from "../../components/cachedImage";
import * as Notifications from 'expo-notifications';
import Constants from 'expo-constants';

export type TodoDetailsRouteParams = {
  todo: Todo;
};

export const TodoDetailsScreen = (
  props: TodoDetailsScreenProps
): LayoutElement => {
  const { todo } = props.route.params;
  const insets: EdgeInsets = useSafeArea();

  return (
    <React.Fragment>
      <CachedImage
        source={{ uri: `${todo.imageUrl}` }}
        cacheKey={`${todo.index}t`}
        style={[styles.appBar, { paddingTop: insets.top }]}
      />
      <Toolbar appearance="control" onBackPress={props.navigation.goBack} />

      <Layout style={styles.container}>
        <View style={styles.detailsContainer}>
          <Text style={styles.title} category="h4">
            {todo.title}
          </Text>
          <Text appearance="hint" category="c1">
            {todo.author}
          </Text>
          <ProgressBar
            style={styles.progressBar}
            progress={todo.progress}
            text={`${todo.progress}%`}
          />
          <ScrollView>
            <Text style={styles.content}>{todo.content}</Text>
          </ScrollView>
        </View>
        <Button onPress={async () => {
          await AsyncStorage.clear()
          Notifications.dismissAllNotificationsAsync();
        }}>COMPLETE</Button>
      </Layout>
    </React.Fragment>
  );
};

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
  },
  container: {
    flex: 1,
    paddingVertical: 4,
    paddingHorizontal: 16,
  },
  detailsContainer: {
    flex: 1,
  },
  appBar: {
    height: 192,
  },
  title: {
    marginVertical: 4,
  },
  content: {
    textAlign: "justify",
    marginVertical: 4,
  },
  progressBar: {
    width: "50%",
    marginVertical: 16,
  },
});
