import React from 'react';
import { ImageBackground, StyleSheet, View } from 'react-native';
import { Button, CheckBox, Layout } from '@ui-kitten/components';
import { Formik, FormikProps } from 'formik';
import { SignInScreenProps } from '../../navigation/auth.navigator';
import { AppRoute } from '../../navigation/app-routes';
import { FormInput } from '../../components/form-input.component';
import { EyeIcon, EyeOffIcon } from '../../assets/icons';
import { SignInData, SignInSchema } from '../../data/sign-in.model';
import { TouchableWithoutFeedback } from 'react-native-gesture-handler';

export const SignInScreen = (props: SignInScreenProps) => {

  const [shouldRemember, setShouldRemember] = React.useState<boolean>(false);
  const [passwordVisible, setPasswordVisible] = React.useState<boolean>(false);

  const onFormSubmit = (values: SignInData): void => {
    navigateHome();
  };

  const navigateHome = (): void => {
    props.navigation.navigate(AppRoute.HOME);
  };

  const navigateSignUp = (): void => {
    props.navigation.navigate(AppRoute.SIGN_UP);
  };

  const navigateResetPassword = (): void => {
    props.navigation.navigate(AppRoute.RESET_PASSWORD);
  };

  const onPasswordIconPress = (): void => {
    setPasswordVisible(!passwordVisible);
  };

  const renderPasswordIcon = (props): React.ReactElement => {
    const IconComponent = passwordVisible ? EyeIcon : EyeOffIcon;
    return (
      <TouchableWithoutFeedback onPress={onPasswordIconPress}>
        <IconComponent {...props} />
      </TouchableWithoutFeedback>
    );
  };

  const renderForm = (props: FormikProps<SignInData>): React.ReactFragment => (
    <React.Fragment>
      <FormInput
        id='email'
        style={styles.formControl}
        placeholder='Email'
        keyboardType='email-address'
      />
      <FormInput
        id='password'
        style={styles.formControl}
        placeholder='Password'
        secureTextEntry={!passwordVisible}
        accessoryRight={renderPasswordIcon}
      />
      <View style={styles.resetPasswordContainer}>
        <CheckBox
          style={styles.formControl}
          checked={shouldRemember}
          onChange={setShouldRemember}>
          Remember Me
        </CheckBox>
        <Button
          appearance='ghost'
          status='basic'
          onPress={navigateResetPassword}>
          Forgot password?
        </Button>
      </View>
      <Button
        style={styles.submitButton}
        onPress={props.handleSubmit}>
        SIGN IN
      </Button>
    </React.Fragment>
  );

  return (
    <React.Fragment>
      <ImageBackground
        style={styles.appBar}
        source={require('../../assets/image-background.jpeg')}
      />
      <Layout style={styles.formContainer}>
        <Formik
          initialValues={SignInData.empty()}
          validationSchema={SignInSchema}
          onSubmit={onFormSubmit}>
          {renderForm}
        </Formik>
        <Button
          style={styles.noAccountButton}
          appearance='ghost'
          status='basic'
          onPress={navigateSignUp}>
          Don't have an account?
        </Button>
      </Layout>
    </React.Fragment>
  );
};

const styles = StyleSheet.create({
  appBar: {
    height: 192,
  },
  formContainer: {
    flex: 1,
    paddingVertical: 16,
    paddingHorizontal: 16,
  },
  resetPasswordContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  formControl: {
    marginVertical: 4,
  },
  submitButton: {
    marginVertical: 24,
  },
  noAccountButton: {
    alignSelf: 'center',
  },
});




















// import React, { useState } from 'react';
// import { ImageBackground, StyleSheet, View } from 'react-native';
// import { Linking } from 'expo';
// import { Button, CheckBox, Layout } from '@ui-kitten/components';
// import { Formik, FormikProps } from 'formik';
// import { SignInScreenProps } from '../../navigation/auth.navigator';
// import { AppRoute } from '../../navigation/app-routes';
// import { FormInput } from '../../components/form-input.component';
// import { EyeIcon, EyeOffIcon } from '../../assets/icons';
// import { SignInData, SignInSchema } from '../../data/sign-in.model';
// import { TouchableWithoutFeedback } from 'react-native-gesture-handler';
// import firebase from 'expo-firebase-app';

// export const SignInScreen = (props: SignInScreenProps) => {
//   const expoLink = Linking.makeUrl('your/expo/link');

//   const FIREBASE_LINK_PROXY = 'https://wt-6e2a5f000b93f69e1b65cf98021e1945-0.sandbox.auth0-extend.com/firebase-authentication-link-redirect';
//   const proxyUrl = `${FIREBASE_LINK_PROXY}?redirectUrl=${encodeURIComponent(expoLink)}`;

//   const [shouldRemember, setShouldRemember] = React.useState<boolean>(false);
//   const [passwordVisible, setPasswordVisible] = React.useState<boolean>(false);
//   const [values, setValues] = React.useState<boolean>();

//   const onFormSubmit = (values: SignInData): void => {
//     navigateHome();
//   };

//   const onChange = (event) => {
//     console.log(event)
//     setValues('hi');
//   };

//   const navigateHome = (): void => {
//     props.navigation.navigate(AppRoute.HOME);
//   };

//   const navigateSignUp = (): void => {
//     props.navigation.navigate(AppRoute.SIGN_UP);
//   };

//   const navigateResetPassword = (): void => {
//     props.navigation.navigate(AppRoute.RESET_PASSWORD);
//   };

//   const onPasswordIconPress = (): void => {
//     setPasswordVisible(!passwordVisible);
//   };

//   const renderPasswordIcon = (props): React.ReactElement => {
//     const IconComponent = passwordVisible ? EyeIcon : EyeOffIcon;
//     return (
//       <TouchableWithoutFeedback onPress={onPasswordIconPress}>
//         <IconComponent {...props} />
//       </TouchableWithoutFeedback>
//     );
//   };

//   const CallSignupFunction = (event: React.ChangeEvent<HTMLInputElement>) => {
//     const email = values
//     alert(JSON.stringify(email))
//     // firebase.auth().sendSignInLinkToEmail(email, {
//     //   handleCodeInApp: true,
//     //   url: proxyUrl
//     // })
//     //   .then(/* ... */)
//     //   .catch(/* ... */)
//   };
//   const renderForm = (props: FormikProps<SignInData>): React.ReactFragment => (
//     <React.Fragment>
//       <FormInput
//         id='email'
//         style={styles.formControl}
//         placeholder='Email'
//         keyboardType='email-address'
//         onChange={(text) => console.log(text.target)}
//       />
//       <FormInput
//         id='password'
//         style={styles.formControl}
//         placeholder='Password'
//         secureTextEntry={!passwordVisible}
//         accessoryRight={renderPasswordIcon}
//       />
//       <View style={styles.resetPasswordContainer}>
//         <CheckBox
//           style={styles.formControl}
//           checked={shouldRemember}
//           onChange={setShouldRemember}>
//           Remember Me
//         </CheckBox>
//         <Button
//           appearance='ghost'
//           status='basic'
//           onPress={navigateResetPassword}>
//           Forgot password?
//         </Button>
//       </View>
//       <Button
//         style={styles.submitButton}
//         onPress={props.handleSubmit}
//       // onPress={CallSignupFunction}
//       >
//         SIGN IN
//       </Button>
//     </React.Fragment>
//   );

//   return (
//     <React.Fragment>
//       <ImageBackground
//         style={styles.appBar}
//         source={require('../../assets/image-background.jpeg')}
//       />
//       <Layout style={styles.formContainer}>
//         <Formik
//           initialValues={SignInData.empty()}
//           validationSchema={SignInSchema}
//           onSubmit={onFormSubmit}>
//           {renderForm}
//         </Formik>
//         <Button
//           style={styles.noAccountButton}
//           appearance='ghost'
//           status='basic'
//           onPress={navigateSignUp}>
//           Don't have an account?
//         </Button>
//       </Layout>
//     </React.Fragment>
//   );
// };

// const styles = StyleSheet.create({
//   appBar: {
//     height: 192,
//   },
//   formContainer: {
//     flex: 1,
//     paddingVertical: 16,
//     paddingHorizontal: 16,
//   },
//   resetPasswordContainer: {
//     flexDirection: 'row',
//     justifyContent: 'space-between',
//   },
//   formControl: {
//     marginVertical: 4,
//   },
//   submitButton: {
//     marginVertical: 24,
//   },
//   noAccountButton: {
//     alignSelf: 'center',
//   },
// });
